#!python
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 2 2016

@author: Nils Jonathan Trost

Script that tracks larvae in circular arenas.

Needs ffmpeg and FIJI to run.
"""

import argparse
import os
from datetime import datetime

import errno

import shutil

from nyanemone.tracking.interactive_crop import Image
from nyanemone.external.runffmpeg import Ffmpeg
from nyanemone.external.runfiji import ImageJMacro
from nyanemone.tracking.analyze_tracks import Analysis
from nyanemone.tracking.analyze_tracks import distance
from nyanemone.tracking.cv_tracking import Video


def silent_remove(filename):
    """removes file without error on non existing file"""
    try:
        os.remove(filename)
    except OSError as err:
        if err.errno != errno.ENOENT:  # errno.ENOENT = no such file or directory
            raise  # re-raise exception if a different error occurred


def prepare_vid(video_name, infile, temp_dir):
    """get FIJI compatible avi from video"""
    ffmpeg = Ffmpeg(infile, temp_dir + video_name)
    ffmpeg.pix_fmt = "nv12"
    ffmpeg.f = "avi"
    ffmpeg.vcodec = "rawvideo"
    ffmpeg.run()


def main():
    """main function to track larvae"""
    args = get_arguments()
    # get all file names and directories ready
    infile = os.path.abspath(args.in_path)
    video_name = os.path.basename(infile)
    video_name_base = os.path.splitext(video_name)[0]
    out_dir = os.path.abspath(args.out_path)
    if not out_dir.endswith('/'):
        out_dir += '/'
    # make directory for temporary results
    temp_dir = os.path.join(out_dir, "temp/")
    seg_path = os.path.join(out_dir, "SEG_" + video_name_base)
    converted_name = video_name_base + "_c.avi"
    start_frame = None
    end_frame = None
    os.makedirs(temp_dir)
    # convert video to raw avi format
    prepare_vid(converted_name, infile, temp_dir)
    # ask for start and end frames
    while not start_frame:
        try:
            start_frame = int(input("First frame to keep: "))
        except ValueError:
            start_frame = False
    while not end_frame:
        try:
            end_frame = int(input("Last frame to keep: ")) + 1
        except ValueError:
            end_frame = False

    # segment the video
    # run the segmentation macro
    if args.median:
        fiji = ImageJMacro("segmentation_median2")
    else:
        fiji = ImageJMacro("segmentation2")
    fiji.run([temp_dir + converted_name, str(start_frame),
              str(end_frame), seg_path])

    # track the segmented video
    vid = Video(seg_path + ".avi")
    tracks = vid.track()

    analysis = Analysis(tracks)
    analysis.save_track_image(temp_dir, out_dir)
    if args.save_track:
        # save track points to file
        analysis.save_track(out_dir, i)

    if not args.keep_temp:
        shutil.rmtree(temp_dir)
        silent_remove(os.path.join(out_dir, "SEG_" + video_name_base + ".avi"))


def get_arguments():
    parser = argparse.ArgumentParser(description="Tracks larvae for thigmotaxis experiment")
    # add options for argument parser
    parser.add_argument("in_path",
                        help="Path to the video.")
    parser.add_argument("out_path",
                        help="Directory for results. Should be empty.")
    parser.add_argument("-x", "--keep_temp", action="store_true",
                        help="Keep temporary folder after execution.")
    parser.add_argument("-i", "--save_track_image", action="store_true",
                        help="Save images of tracked paths.")
    parser.add_argument("--median", action="store_true",
                        help="Use median intensity projection for segmentation.")
    # parse arguments from command line
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    start = datetime.now()
    main()
    end = datetime.now()
    print("\nExecuted in " + str(end - start))
